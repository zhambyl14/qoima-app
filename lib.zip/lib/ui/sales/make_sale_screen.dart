import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/app_user.dart';
import '../../core/warehouse_context.dart';
import '../../data/models/models.dart';
import '../../data/services/firestore_service.dart';
import '../../theme/app_theme.dart';

// ── CartItem ──────────────────────────────────────────────────────────────────
class CartItem {
  final ProductModel product;
  final BatchModel batch;
  Map<String, int> sizes;
  double discountPercent;

  CartItem({
    required this.product,
    required this.batch,
    Map<String, int>? sizes,
    this.discountPercent = 0,
  }) : sizes = sizes ?? {};

  int get qty => sizes.values.fold(0, (a, b) => a + b);
  double get base  => batch.sellingPrice * qty;
  double get total => base * (1 - discountPercent / 100);
  double get discountAmount => base - total;
}

// ── MakeSaleScreen ────────────────────────────────────────────────────────────
class MakeSaleScreen extends StatefulWidget {
  const MakeSaleScreen({super.key});
  @override
  State<MakeSaleScreen> createState() => _MakeSaleScreenState();
}

class _MakeSaleScreenState extends State<MakeSaleScreen> {
  final _service = FirestoreService();

  int _step = 0; // 0 = товар таңдау, 1 = размер + скидка

  // Қадам 1
  final Set<String> _selectedIds = {};
  List<ProductModel> _products = [];
  bool _loadingProducts = true;

  // Қадам 2
  List<CartItem> _cart = [];
  bool _isConfirming = false;

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    _service.watchProducts().first.then((list) {
      if (mounted) { setState(() { _products = list; _loadingProducts = false; }); }
    });
  }

  List<ProductModel> get _inStockProducts =>
      _products.where((p) => p.status == ProductModel.statusInStock).toList();

  String get _activeWarehouseId {
    if (AppUser.isAdmin) {
      return context.read<WarehouseContext>().current?.id ?? '';
    }
    return AppUser.assignedWarehouseId;
  }

  // ── Қадам 1 → 2: таңдалған товарлар үшін Cart жасау ─────────────────────
  Future<void> _goToStep2() async {
    if (_selectedIds.isEmpty) return;
    setState(() => _isConfirming = true);
    final whId = _activeWarehouseId;
    final items = <CartItem>[];
    for (final id in _selectedIds) {
      final prod = _products.firstWhere((p) => p.id == id);
      final batches = await _service.getBatches(id);
      // Warehouse бойынша фильтрлейміз (бос болса — барлығын қарастырамыз)
      final whBatches = whId.isNotEmpty
          ? batches.where((b) => b.warehouseId == whId).toList()
          : batches;
      final pool = whBatches.isNotEmpty ? whBatches : batches;
      final activeBatch = pool.firstWhere(
        (b) => b.sizesQuantity.values.any((q) => q > 0),
        orElse: () => pool.first,
      );
      items.add(CartItem(product: prod, batch: activeBatch));
    }
    if (mounted) setState(() { _cart = items; _step = 1; _isConfirming = false; });
  }

  // ── Сатуды растау ─────────────────────────────────────────────────────────
  Future<void> _confirm() async {
    final validItems = _cart.where((c) => c.qty > 0).toList();
    if (validItems.isEmpty) {
      _snack('Кем дегенде 1 жұп таңдаңыз', isError: true);
      return;
    }
    setState(() => _isConfirming = true);
    final whId = _activeWarehouseId;
    try {
      for (final item in validItems) {
        await _service.makeSale(
          productId:       item.product.id,
          batchId:         item.batch.id,
          sizesSold:       Map.from(item.sizes),
          discountPercent: item.discountPercent,
          warehouseId:     whId,
        );
      }
      final totalQty   = validItems.fold(0, (s, c) => s + c.qty);
      final totalPrice = validItems.fold(0.0, (s, c) => s + c.total);
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Row(children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 8),
            Text('Сатылды $totalQty жұп · ${totalPrice.toStringAsFixed(0)} ₸'),
          ]),
          backgroundColor: AppTheme.success,
          behavior: SnackBarBehavior.floating,
        ));
      }
    } catch (e) {
      _snack(e.toString().replaceFirst('SaleException: ', ''), isError: true);
    } finally {
      if (mounted) setState(() => _isConfirming = false);
    }
  }

  void _snack(String msg, {bool isError = false}) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: isError ? AppTheme.danger : AppTheme.success,
        behavior: SnackBarBehavior.floating,
      ));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: SafeArea(child: Column(children: [
        // ── Header ────────────────────────────────────────────────────
        Container(
          decoration: const BoxDecoration(gradient: LinearGradient(
              colors: [Color(0xFF1E3A8A), Color(0xFF2D4FB5)],
              begin: Alignment.topLeft, end: Alignment.bottomRight)),
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Row(children: [
            GestureDetector(
              onTap: () {
                if (_step == 1) { setState(() => _step = 0); }
                else { Navigator.pop(context); }
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.arrow_back_ios_new,
                    color: Colors.white, size: 16))),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_step == 0 ? 'Сату' : 'Размер және скидка',
                  style: const TextStyle(color: Colors.white, fontSize: 18,
                      fontWeight: FontWeight.w700)),
              Text(_step == 0
                  ? '${_selectedIds.length} товар таңдалды'
                  : '${_cart.length} товар',
                  style: const TextStyle(color: Colors.white60, fontSize: 12)),
            ])),
            // Қадам индикатор
            _StepBadge(step: _step),
          ]),
        ),

        // ── Мазмұн ────────────────────────────────────────────────────
        Expanded(
          child: _step == 0
              ? _Step1(
                  products: _inStockProducts,
                  loading: _loadingProducts,
                  selectedIds: _selectedIds,
                  onToggle: (id) => setState(() {
                    if (_selectedIds.contains(id)) { _selectedIds.remove(id); }
                    else { _selectedIds.add(id); }
                  }),
                )
              : _Step2(
                  cart: _cart,
                  onSizeChanged: (ci, sizes) =>
                      setState(() => _cart[ci].sizes = sizes),
                  onDiscount: (ci) => _showDiscountSheet(ci),
                  onRemove: (ci) => setState(() {
                    _cart.removeAt(ci);
                    if (_cart.isEmpty) _step = 0;
                  }),
                ),
        ),

        // ── Sticky footer ─────────────────────────────────────────────
        _Footer(
          step: _step,
          selectedCount: _selectedIds.length,
          cart: _cart,
          isLoading: _isConfirming,
          onNext: _step == 0 ? _goToStep2 : _confirm,
        ),
      ])),
    );
  }

  // ── Скидка Modal ──────────────────────────────────────────────────────────
  void _showDiscountSheet(int cartIndex) {
    final item = _cart[cartIndex];
    bool byPercent = true;
    final ctrl = TextEditingController(
        text: item.discountPercent > 0
            ? item.discountPercent.toStringAsFixed(0)
            : '');
    final presets = [5, 10, 15, 20, 25, 30];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          void applyPercent(double pct) {
            ctrl.text = pct.toStringAsFixed(0);
          }
          return Padding(
            padding: EdgeInsets.only(
                left: 20, right: 20, top: 16,
                bottom: MediaQuery.of(ctx).viewInsets.bottom + 24),
            child: Column(mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
              Center(child: Container(width: 36, height: 4,
                  decoration: BoxDecoration(color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2)))),
              const SizedBox(height: 14),
              Text('${item.product.name} — Скидка',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary)),
              const SizedBox(height: 4),
              Text('Базалық баға: ${item.base.toStringAsFixed(0)} ₸',
                  style: const TextStyle(fontSize: 13, color: AppTheme.textSecondary)),
              const SizedBox(height: 14),
              // Toggle
              Row(children: [
                _ToggleBtn(label: '% Проценттен', active: byPercent,
                    onTap: () => setS(() => byPercent = true)),
                const SizedBox(width: 8),
                _ToggleBtn(label: '₸ Жаңа баға', active: !byPercent,
                    onTap: () => setS(() => byPercent = false)),
              ]),
              const SizedBox(height: 12),
              // Preset chips
              if (byPercent)
                Wrap(spacing: 8, runSpacing: 8,
                  children: presets.map((p) => GestureDetector(
                    onTap: () { setS(() {}); applyPercent(p.toDouble()); },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                          color: AppTheme.primary.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppTheme.primary.withValues(alpha: 0.2))),
                      child: Text('$p%', style: const TextStyle(
                          fontWeight: FontWeight.w600, color: AppTheme.primary))),
                  )).toList()),
              const SizedBox(height: 12),
              // Енгізу
              TextField(
                controller: ctrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'^\d*\.?\d*'))],
                style: const TextStyle(fontSize: 15, color: AppTheme.textPrimary),
                decoration: InputDecoration(
                  labelText: byPercent ? 'Скидка %' : 'Соңғы баға ₸',
                  suffixText: byPercent ? '%' : '₸',
                  filled: true, fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppTheme.border)),
                  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: AppTheme.primary, width: 1.5)),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, height: 48,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primary, foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      elevation: 0),
                  onPressed: () {
                    final val = double.tryParse(ctrl.text) ?? 0;
                    double pct;
                    if (byPercent) {
                      pct = val.clamp(0, 100);
                    } else {
                      // Жаңа баға → пайыз есептеу
                      pct = item.base > 0
                          ? ((1 - val / item.base) * 100).clamp(0, 100)
                          : 0;
                    }
                    setState(() => _cart[cartIndex].discountPercent = pct);
                    Navigator.pop(ctx);
                  },
                  child: const Text('Қолдану',
                      style: TextStyle(fontWeight: FontWeight.w700)))),
            ]),
          );
        },
      ),
    );
  }
}

// ── Қадам 1: Товар таңдау ─────────────────────────────────────────────────────
class _Step1 extends StatelessWidget {
  final List<ProductModel> products;
  final bool loading;
  final Set<String> selectedIds;
  final void Function(String) onToggle;

  const _Step1({required this.products, required this.loading,
      required this.selectedIds, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
    }
    if (products.isEmpty) {
      return const Center(child: Padding(
        padding: EdgeInsets.all(32),
        child: Text('Қоймада тауар жоқ',
            style: TextStyle(color: AppTheme.textSecondary, fontSize: 15)),
      ));
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      itemCount: products.length,
      itemBuilder: (_, i) {
        final p   = products[i];
        final sel = selectedIds.contains(p.id);
        return GestureDetector(
          onTap: () => onToggle(p.id),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: sel ? AppTheme.primary.withValues(alpha: 0.06) : Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: sel ? AppTheme.primary : AppTheme.border,
                  width: sel ? 1.5 : 1),
              boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04),
                  blurRadius: 6, offset: const Offset(0, 2))],
            ),
            child: Row(children: [
              // Чекбокс
              AnimatedContainer(duration: const Duration(milliseconds: 160),
                width: 22, height: 22,
                decoration: BoxDecoration(
                    color: sel ? AppTheme.primary : Colors.transparent,
                    border: Border.all(
                        color: sel ? AppTheme.primary : AppTheme.border, width: 2),
                    borderRadius: BorderRadius.circular(6)),
                child: sel
                    ? const Icon(Icons.check, color: Colors.white, size: 14)
                    : null),
              const SizedBox(width: 12),
              // Сурет
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: p.images.isNotEmpty
                    ? Image.network(p.images.first, width: 44, height: 44,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _img())
                    : _img()),
              const SizedBox(width: 12),
              // Ақпарат
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.name, style: const TextStyle(fontWeight: FontWeight.w700,
                    fontSize: 14, color: AppTheme.textPrimary),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                Text('${p.brand} · ${p.type}',
                    style: const TextStyle(fontSize: 11, color: AppTheme.textSecondary)),
              ])),
            ]),
          ),
        );
      },
    );
  }

  Widget _img() => Container(
      width: 44, height: 44,
      decoration: BoxDecoration(color: AppTheme.primary.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(8)),
      child: const Icon(Icons.inventory_2_outlined, color: AppTheme.primary, size: 20));
}

// ── Қадам 2: Размерлер + скидка ──────────────────────────────────────────────
class _Step2 extends StatelessWidget {
  final List<CartItem> cart;
  final void Function(int, Map<String, int>) onSizeChanged;
  final void Function(int) onDiscount;
  final void Function(int) onRemove;

  const _Step2({required this.cart, required this.onSizeChanged,
      required this.onDiscount, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      itemCount: cart.length,
      itemBuilder: (_, ci) => _CartCard(
        item: cart[ci],
        cartIndex: ci,
        onSizeChanged: (s) => onSizeChanged(ci, s),
        onDiscount: () => onDiscount(ci),
        onRemove: () => onRemove(ci),
      ),
    );
  }
}

class _CartCard extends StatelessWidget {
  final CartItem item;
  final int cartIndex;
  final void Function(Map<String, int>) onSizeChanged;
  final VoidCallback onDiscount;
  final VoidCallback onRemove;

  const _CartCard({required this.item, required this.cartIndex,
      required this.onSizeChanged, required this.onDiscount, required this.onRemove});

  Map<String, int> get _availSizes {
    final m = Map.fromEntries(
      item.batch.sizesQuantity.entries.where((e) => e.value > 0));
    final sorted = m.entries.toList()
      ..sort((a, b) => (int.tryParse(a.key) ?? 0).compareTo(int.tryParse(b.key) ?? 0));
    return Map.fromEntries(sorted);
  }

  void _setQty(BuildContext ctx, String size, int qty) {
    final max = _availSizes[size] ?? 0;
    final newSizes = Map<String, int>.from(item.sizes);
    if (qty <= 0) { newSizes.remove(size); }
    else { newSizes[size] = qty.clamp(0, max); }
    onSizeChanged(newSizes);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 8, offset: const Offset(0, 2))]),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Товар жолы
          Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(8),
              child: item.product.images.isNotEmpty
                  ? Image.network(item.product.images.first, width: 40, height: 40,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _img())
                  : _img()),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(item.product.name, style: const TextStyle(fontWeight: FontWeight.w700,
                  fontSize: 14, color: AppTheme.textPrimary),
                  maxLines: 1, overflow: TextOverflow.ellipsis),
              Text('${item.batch.sellingPrice.toStringAsFixed(0)} ₸/жұп',
                  style: const TextStyle(fontSize: 12, color: AppTheme.textSecondary)),
            ])),
            // Жою
            GestureDetector(
              onTap: onRemove,
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: AppTheme.dangerLight,
                    borderRadius: BorderRadius.circular(8)),
                child: const Icon(Icons.close, size: 14, color: AppTheme.danger))),
          ]),
          const SizedBox(height: 12),

          // Размер чиптері
          if (_availSizes.isEmpty)
            const Text('Бұл партияда қалдық жоқ',
                style: TextStyle(color: AppTheme.danger, fontSize: 12))
          else
            Wrap(spacing: 8, runSpacing: 8,
              children: _availSizes.entries.map((e) {
                final size  = e.key;
                final maxQ  = e.value;
                final cartQ = item.sizes[size] ?? 0;
                return _SizeChip(
                  size: size, max: maxQ, cartQty: cartQ,
                  onMinus: () => _setQty(context, size, cartQ - 1),
                  onPlus:  () => _setQty(context, size, cartQ + 1),
                  onTap: () => _showQtyInput(context, size, maxQ, cartQ),
                );
              }).toList()),

          const SizedBox(height: 12),

          // Скидка жолы
          Row(children: [
            GestureDetector(
              onTap: onDiscount,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                    color: item.discountPercent > 0
                        ? AppTheme.warning.withValues(alpha: 0.1)
                        : AppTheme.background,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: item.discountPercent > 0
                            ? AppTheme.warning.withValues(alpha: 0.5)
                            : AppTheme.border)),
                child: item.discountPercent > 0
                    ? Row(mainAxisSize: MainAxisSize.min, children: [
                        const Icon(Icons.discount_outlined,
                            size: 14, color: AppTheme.warning),
                        const SizedBox(width: 4),
                        Text('-${item.discountPercent.toStringAsFixed(0)}% · '
                            '${item.total.toStringAsFixed(0)} ₸',
                            style: const TextStyle(fontSize: 12,
                                color: AppTheme.warning, fontWeight: FontWeight.w600)),
                      ])
                    : const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.add, size: 14, color: AppTheme.textHint),
                        SizedBox(width: 4),
                        Text('Скидка қосу', style: TextStyle(
                            fontSize: 12, color: AppTheme.textHint)),
                      ]),
              ),
            ),
            const Spacer(),
            if (item.qty > 0)
              Text('${item.total.toStringAsFixed(0)} ₸',
                  style: const TextStyle(fontWeight: FontWeight.w800,
                      fontSize: 16, color: AppTheme.primary)),
          ]),
        ]),
      ),
    );
  }

  Widget _img() => Container(
      width: 40, height: 40,
      decoration: BoxDecoration(color: AppTheme.primary.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(8)),
      child: const Icon(Icons.inventory_2_outlined, color: AppTheme.primary, size: 18));

  void _showQtyInput(BuildContext ctx, String size, int max, int current) {
    final ctrl = TextEditingController(text: '$current');
    showDialog(context: ctx, builder: (dCtx) => AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Text('Размер $size · макс $max жұп',
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
      content: TextField(
        controller: ctrl,
        keyboardType: TextInputType.number,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        autofocus: true,
        decoration: InputDecoration(
          suffixText: 'жұп',
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: AppTheme.primary, width: 1.5)))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dCtx),
            child: const Text('Болдырмау',
                style: TextStyle(color: AppTheme.textSecondary))),
        ElevatedButton(
          onPressed: () {
            final v = int.tryParse(ctrl.text) ?? 0;
            _setQty(ctx, size, v.clamp(0, max));
            Navigator.pop(dCtx);
          },
          style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
          child: const Text('ОК')),
      ],
    ));
  }
}

// ── Size Chip ─────────────────────────────────────────────────────────────────
class _SizeChip extends StatelessWidget {
  final String size;
  final int max, cartQty;
  final VoidCallback onMinus, onPlus, onTap;

  const _SizeChip({required this.size, required this.max, required this.cartQty,
      required this.onMinus, required this.onPlus, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final active = cartQty > 0;
    return Container(
      decoration: BoxDecoration(
          color: active ? AppTheme.primary.withValues(alpha: 0.06) : AppTheme.background,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
              color: active ? AppTheme.primary.withValues(alpha: 0.4) : AppTheme.border,
              width: active ? 1.5 : 1)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        GestureDetector(
          onTap: cartQty > 0 ? onMinus : null,
          child: Container(
            width: 28, height: 28,
            decoration: BoxDecoration(
                color: cartQty > 0 ? AppTheme.primary : Colors.grey.shade100,
                borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(9), bottomLeft: Radius.circular(9))),
            child: Icon(Icons.remove, size: 14,
                color: cartQty > 0 ? Colors.white : Colors.grey.shade400))),
        GestureDetector(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Column(mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(size, style: TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w700,
                    color: active ? AppTheme.primary : AppTheme.textPrimary)),
                Text(cartQty > 0 ? '$cartQty' : '0',
                    style: TextStyle(fontSize: 11,
                        color: active ? AppTheme.primary : AppTheme.textHint,
                        fontWeight: active ? FontWeight.w700 : FontWeight.w400)),
              ],
            ),
          )),
        GestureDetector(
          onTap: cartQty < max ? onPlus : null,
          child: Container(
            width: 28, height: 28,
            decoration: BoxDecoration(
                color: cartQty < max ? AppTheme.primary : Colors.grey.shade100,
                borderRadius: const BorderRadius.only(
                    topRight: Radius.circular(9), bottomRight: Radius.circular(9))),
            child: Icon(Icons.add, size: 14,
                color: cartQty < max ? Colors.white : Colors.grey.shade400))),
      ]),
    );
  }
}

// ── Footer ────────────────────────────────────────────────────────────────────
class _Footer extends StatelessWidget {
  final int step, selectedCount;
  final List<CartItem> cart;
  final bool isLoading;
  final VoidCallback onNext;

  const _Footer({required this.step, required this.selectedCount,
      required this.cart, required this.isLoading, required this.onNext});

  @override
  Widget build(BuildContext context) {
    final totalQty   = cart.fold(0, (s, c) => s + c.qty);
    final baseTotal  = cart.fold(0.0, (s, c) => s + c.base);
    final finalTotal = cart.fold(0.0, (s, c) => s + c.total);
    final hasDiscount = baseTotal != finalTotal;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      decoration: BoxDecoration(color: Colors.white,
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.08),
              blurRadius: 16, offset: const Offset(0, -4))]),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (step == 1 && totalQty > 0) ...[
          if (hasDiscount)
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Жалпы (N жұп):',
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
              Text('${baseTotal.toStringAsFixed(0)} ₸',
                  style: const TextStyle(fontSize: 13, color: AppTheme.textHint,
                      decoration: TextDecoration.lineThrough)),
            ]),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text('Барлығы: $totalQty жұп',
                style: const TextStyle(color: AppTheme.textSecondary, fontSize: 14)),
            Text('${finalTotal.toStringAsFixed(0)} ₸',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800,
                    color: AppTheme.primary)),
          ]),
          const SizedBox(height: 10),
        ],
        SizedBox(width: double.infinity, height: 50,
          child: ElevatedButton.icon(
            onPressed: isLoading
                ? null
                : (step == 0 && selectedCount == 0) ? null : onNext,
            icon: isLoading
                ? const SizedBox(width: 18, height: 18,
                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : Icon(step == 0
                    ? Icons.arrow_forward_rounded
                    : Icons.check_circle_outline_rounded),
            label: Text(
              step == 0
                  ? 'Үшін қарай · $selectedCount товар →'
                  : 'Сатуды растау · ${finalTotal.toStringAsFixed(0)} ₸',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primary, foregroundColor: Colors.white,
              disabledBackgroundColor: Colors.grey.shade200,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              elevation: 0),
          )),
      ]),
    );
  }
}

// ── Step Badge ────────────────────────────────────────────────────────────────
class _StepBadge extends StatelessWidget {
  final int step;
  const _StepBadge({required this.step});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(20)),
    child: Text('${step + 1} / 2', style: const TextStyle(
        color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
  );
}

// ── Toggle Button ─────────────────────────────────────────────────────────────
class _ToggleBtn extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _ToggleBtn({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
          color: active ? AppTheme.primary : AppTheme.background,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: active ? AppTheme.primary : AppTheme.border)),
      child: Text(label, style: TextStyle(
          fontWeight: FontWeight.w600, fontSize: 13,
          color: active ? Colors.white : AppTheme.textSecondary)),
    ),
  );
}
