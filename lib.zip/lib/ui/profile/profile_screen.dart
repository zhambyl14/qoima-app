import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/app_user.dart';
import '../../data/services/auth_service.dart';
import '../../theme/app_theme.dart';
import 'sellers_screen.dart';
import 'warehouses_screen.dart';
import 'transfers_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final name    = AppUser.name;
    final email   = AppUser.email;
    final isAdmin = AppUser.isAdmin;
    final initials = name.trim().split(' ')
        .map((w) => w.isNotEmpty ? w[0].toUpperCase() : '')
        .take(2)
        .join();

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: CustomScrollView(slivers: [
        // ── Header ──────────────────────────────────────────────────────
        SliverToBoxAdapter(child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors: [Color(0xFF1E3A8A), Color(0xFF2D4FB5)],
                begin: Alignment.topLeft, end: Alignment.bottomRight)),
          child: SafeArea(bottom: false, child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
            child: Column(children: [
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: Colors.white.withValues(alpha: 0.4), width: 2)),
                child: Center(child: Text(initials.isEmpty ? '?' : initials,
                    style: const TextStyle(color: Colors.white, fontSize: 26,
                        fontWeight: FontWeight.w700)))),
              const SizedBox(height: 12),
              Text(name.isEmpty ? '...' : name,
                  style: const TextStyle(color: Colors.white, fontSize: 18,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(email,
                  style: const TextStyle(color: Colors.white60, fontSize: 13)),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: Colors.white.withValues(alpha: 0.3))),
                child: Text(
                  isAdmin ? '🏪 Дүкен иесі' : '🏷️ Сатушы',
                  style: const TextStyle(color: Colors.white, fontSize: 12,
                      fontWeight: FontWeight.w600),
                )),

              // Бизнес-код карточка (тек admin үшін)
              if (isAdmin && AppUser.businessCode.isNotEmpty) ...[
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: Colors.white.withValues(alpha: 0.25))),
                  child: Column(children: [
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      const Row(children: [
                        Icon(Icons.vpn_key_rounded, color: Colors.white70, size: 14),
                        SizedBox(width: 6),
                        Text('Бизнес-код',
                            style: TextStyle(color: Colors.white60, fontSize: 11)),
                      ]),
                      GestureDetector(
                        onTap: () {
                          Clipboard.setData(
                              ClipboardData(text: AppUser.businessCode));
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Бизнес-код көшірілді'),
                              duration: Duration(seconds: 2),
                              behavior: SnackBarBehavior.floating,
                            ),
                          );
                        },
                        child: const Row(children: [
                          Icon(Icons.copy_rounded, color: Colors.white60, size: 13),
                          SizedBox(width: 4),
                          Text('Көшіру',
                              style: TextStyle(color: Colors.white60, fontSize: 11)),
                        ]),
                      ),
                    ]),
                    const SizedBox(height: 8),
                    Text(
                      _formatCode(AppUser.businessCode),
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 8),
                    ),
                  ]),
                ),
              ],
            ]),
          )),
        )),

        // ── Меню ────────────────────────────────────────────────────────
        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(delegate: SliverChildListDelegate([
            const SizedBox(height: 8),

            if (isAdmin) ...[
              _MenuItem(
                icon: Icons.group_outlined,
                color: AppTheme.primary,
                title: 'Сатушылар',
                subtitle: 'Жалданбал сатушыларды басқару',
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const SellersScreen())),
              ),
              const SizedBox(height: 8),
              _MenuItem(
                icon: Icons.warehouse_outlined,
                color: const Color(0xFF059669),
                title: 'Қоймалар',
                subtitle: 'Қойма желісін басқару',
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const WarehousesScreen())),
              ),
              const SizedBox(height: 8),
              _MenuItem(
                icon: Icons.swap_horiz_rounded,
                color: const Color(0xFF7C3AED),
                title: 'Перемещениялар',
                subtitle: 'Қоймалар арасындағы тасымал',
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const TransfersScreen())),
              ),
              const SizedBox(height: 8),
            ],

            _MenuItem(
              icon: Icons.info_outline_rounded,
              color: AppTheme.primary,
              title: 'Қолданба туралы',
              subtitle: 'Qoima v2.2 — Аяқ киім есебі',
              onTap: () {},
            ),
            const SizedBox(height: 24),

            // Шығу
            Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(
                      color: Colors.black.withValues(alpha: 0.04),
                      blurRadius: 8, offset: const Offset(0, 2))]),
              child: ListTile(
                leading: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: AppTheme.dangerLight,
                      borderRadius: BorderRadius.circular(8)),
                  child: const Icon(Icons.logout_rounded,
                      color: AppTheme.danger, size: 20)),
                title: const Text('Шығу', style: TextStyle(
                    color: AppTheme.danger, fontWeight: FontWeight.w600)),
                trailing: const Icon(Icons.chevron_right_rounded,
                    color: AppTheme.textHint),
                onTap: () async {
                  final ok = await showDialog<bool>(context: context,
                    builder: (ctx) => AlertDialog(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                      title: const Text('Шығу',
                          style: TextStyle(fontWeight: FontWeight.w700)),
                      content: const Text('Шықпақшысыз ба?'),
                      actions: [
                        TextButton(
                            onPressed: () => Navigator.pop(ctx, false),
                            child: const Text('Болдырмау',
                                style: TextStyle(color: AppTheme.textSecondary))),
                        ElevatedButton(
                          onPressed: () => Navigator.pop(ctx, true),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.danger,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(10))),
                          child: const Text('Шығу')),
                      ],
                    ));
                  if (ok == true && context.mounted) {
                    await AuthService().signOut();
                  }
                },
              ),
            ),

            const SizedBox(height: 32),
          ])),
        ),
      ]),
    );
  }

  static String _formatCode(String code) {
    if (code.length != 6) return code;
    return '${code.substring(0, 3)} ${code.substring(3)}';
  }
}


class _MenuItem extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title, subtitle;
  final VoidCallback onTap;

  const _MenuItem({
    required this.icon, required this.color,
    required this.title, required this.subtitle, required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 8, offset: const Offset(0, 2))]),
    child: ListTile(
      leading: Container(padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(8)),
        child: Icon(icon, color: color, size: 20)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w500,
          color: AppTheme.textPrimary)),
      subtitle: Text(subtitle,
          style: const TextStyle(color: AppTheme.textHint, fontSize: 12)),
      trailing: const Icon(Icons.chevron_right_rounded, color: AppTheme.textHint),
      onTap: onTap,
    ),
  );
}
