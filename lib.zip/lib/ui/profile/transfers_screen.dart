import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/warehouse_context.dart';
import '../../data/models/warehouse_model.dart';
import '../../data/models/product_model.dart';
import '../../data/services/firestore_service.dart';
import '../../theme/app_theme.dart';

class TransfersScreen extends StatelessWidget {
  const TransfersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final service = FirestoreService();
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: service.watchTransfers(),
        builder: (context, snap) {
          final transfers = snap.data ?? [];
          return CustomScrollView(slivers: [
            SliverToBoxAdapter(child: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                    colors: [Color(0xFF1E3A8A), Color(0xFF2D4FB5)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight)),
              child: SafeArea(bottom: false, child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
                child: Row(children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(10)),
                      child: const Icon(Icons.arrow_back_ios_new,
                          color: Colors.white, size: 16))),
                  const SizedBox(width: 12),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Перемещения', style: TextStyle(color: Colors.white,
                        fontSize: 20, fontWeight: FontWeight.w700)),
                    Text('Қоймалар арасындағы тасымал',
                        style: TextStyle(color: Colors.white60, fontSize: 12)),
                  ])),
                  GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(
                        builder: (_) => const NewTransferScreen())),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(10)),
                      child: const Icon(Icons.add, color: Colors.white, size: 22))),
                ]),
              )),
            )),

            if (transfers.isEmpty)
              SliverFillRemaining(child: Center(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.swap_horiz_rounded, size: 64, color: Colors.grey.shade300),
                  const SizedBox(height: 16),
                  const Text('Перемещение жоқ',
                      style: TextStyle(fontSize: 16, color: AppTheme.textSecondary,
                          fontWeight: FontWeight.w500)),
                ]),
              ))
            else
              SliverPadding(
                padding: const EdgeInsets.all(16),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (_, i) => _TransferCard(t: transfers[i]),
                    childCount: transfers.length,
                  ),
                ),
              ),
          ]);
        },
      ),
    );
  }
}

class _TransferCard extends StatelessWidget {
  final Map<String, dynamic> t;
  const _TransferCard({required this.t});

  @override
  Widget build(BuildContext context) {
    final productName = t['productName'] as String? ?? '—';
    final qty         = t['totalQuantity'] as int? ?? 0;
    final from        = t['fromWarehouseId'] as String? ?? '';
    final to          = t['toWarehouseId']   as String? ?? '';
    final createdAt   = (t['createdAt'] as dynamic);
    String dateStr = '';
    if (createdAt != null) {
      try {
        final dt = createdAt.toDate() as DateTime;
        dateStr = '${dt.day.toString().padLeft(2, '0')}.${dt.month.toString().padLeft(2, '0')}.${dt.year}';
      } catch (_) {}
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 8, offset: const Offset(0, 2))]),
      child: Row(children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
              color: AppTheme.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10)),
          child: const Icon(Icons.swap_horiz_rounded,
              color: AppTheme.primary, size: 20)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(productName, style: const TextStyle(fontSize: 13,
              fontWeight: FontWeight.w600, color: AppTheme.textPrimary),
              maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 2),
          Row(children: [
            Text(from.length > 8 ? '${from.substring(0, 8)}…' : from,
                style: const TextStyle(fontSize: 11, color: AppTheme.textHint)),
            const Icon(Icons.arrow_forward_rounded, size: 12, color: AppTheme.textHint),
            Text(to.length > 8 ? '${to.substring(0, 8)}…' : to,
                style: const TextStyle(fontSize: 11, color: AppTheme.textHint)),
          ]),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('$qty жұп', style: const TextStyle(fontSize: 13,
              fontWeight: FontWeight.w700, color: AppTheme.primary)),
          if (dateStr.isNotEmpty)
            Text(dateStr, style: const TextStyle(fontSize: 11, color: AppTheme.textHint)),
        ]),
      ]),
    );
  }
}

// ── Жаңа перемещение ──────────────────────────────────────────────────────────
class NewTransferScreen extends StatefulWidget {
  const NewTransferScreen({super.key});
  @override
  State<NewTransferScreen> createState() => _NewTransferScreenState();
}

class _NewTransferScreenState extends State<NewTransferScreen> {
  final _service = FirestoreService();

  WarehouseModel? _fromWh;
  WarehouseModel? _toWh;
  ProductModel?   _product;
  Map<String, int> _sizes = {};
  bool _loading = false;
  String? _error;

  @override
  Widget build(BuildContext context) {
    final warehouses = context.watch<WarehouseContext>().all;

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xFF1E3A8A), Color(0xFF2D4FB5)],
                begin: Alignment.topLeft, end: Alignment.bottomRight)),
          child: SafeArea(bottom: false, child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
            child: Row(children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.arrow_back_ios_new,
                      color: Colors.white, size: 16))),
              const SizedBox(width: 12),
              const Text('Жаңа перемещение', style: TextStyle(color: Colors.white,
                  fontSize: 18, fontWeight: FontWeight.w700)),
            ]),
          )),
        )),

        SliverPadding(
          padding: const EdgeInsets.all(16),
          sliver: SliverList(delegate: SliverChildListDelegate([

            // From / To қойма таңдау
            _SectionLabel('Қоймалар'),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: _WhChip(
                label: 'Қайдан', selected: _fromWh,
                warehouses: warehouses.where((w) => w != _toWh).toList(),
                onSelect: (w) => setState(() { _fromWh = w; _product = null; _sizes = {}; }),
              )),
              Container(margin: const EdgeInsets.symmetric(horizontal: 8),
                child: const Icon(Icons.arrow_forward_rounded, color: AppTheme.textHint)),
              Expanded(child: _WhChip(
                label: 'Қайда', selected: _toWh,
                warehouses: warehouses.where((w) => w != _fromWh).toList(),
                onSelect: (w) => setState(() { _toWh = w; }),
              )),
            ]),

            const SizedBox(height: 16),

            // Тауар таңдау
            if (_fromWh != null) ...[
              _SectionLabel('Тауар'),
              const SizedBox(height: 8),
              _ProductPicker(
                service: _service,
                warehouseId: _fromWh!.id,
                selected: _product,
                onSelect: (p) => setState(() { _product = p; _sizes = {}; }),
              ),
            ],

            // Размерлер
            if (_product != null && _fromWh != null) ...[
              const SizedBox(height: 16),
              _SectionLabel('Санды таңдаңыз'),
              const SizedBox(height: 8),
              _SizeSelector(
                service: _service,
                productId: _product!.id,
                warehouseId: _fromWh!.id,
                sizes: _sizes,
                onChanged: (s) => setState(() => _sizes = s),
              ),
            ],

            if (_error != null) ...[
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: AppTheme.dangerLight,
                    borderRadius: BorderRadius.circular(10)),
                child: Text(_error!, style: const TextStyle(
                    color: AppTheme.danger, fontSize: 13)),
              ),
            ],

            const SizedBox(height: 24),
          ])),
        ),
      ]),

      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            if (_sizes.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(
                  'Барлығы: ${_sizes.values.fold(0, (a, b) => a + b)} жұп',
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600,
                      color: AppTheme.textPrimary),
                ),
              ),
            SizedBox(
              width: double.infinity, height: 52,
              child: ElevatedButton(
                onPressed: (_fromWh != null && _toWh != null && _product != null &&
                    _sizes.isNotEmpty && !_loading) ? _transfer : null,
                style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primary, foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    elevation: 0),
                child: _loading
                    ? const SizedBox(width: 22, height: 22,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Перемещение жасау',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _transfer() async {
    setState(() { _loading = true; _error = null; });
    try {
      final transferSizes = Map<String, int>.from(_sizes)
        ..removeWhere((_, v) => v <= 0);
      if (transferSizes.isEmpty) throw Exception('Кем дегенде 1 жұп таңдаңыз');
      await _service.transferStock(
        fromWarehouseId: _fromWh!.id,
        toWarehouseId:   _toWh!.id,
        productId:       _product!.id,
        productName:     _product!.name,
        sizes:           transferSizes,
      );
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }
}

// ── Helper widgets ────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
      style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
          color: AppTheme.textSecondary));
}

class _WhChip extends StatelessWidget {
  final String label;
  final WarehouseModel? selected;
  final List<WarehouseModel> warehouses;
  final ValueChanged<WarehouseModel> onSelect;
  const _WhChip({required this.label, required this.selected,
      required this.warehouses, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        if (warehouses.isEmpty) return;
        final result = await showModalBottomSheet<WarehouseModel>(
          context: context,
          shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
          builder: (_) => ListView(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            children: [
              Text(label, style: const TextStyle(fontSize: 16,
                  fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
              const SizedBox(height: 12),
              ...warehouses.map((w) => ListTile(
                title: Text(w.name),
                leading: const Icon(Icons.warehouse_rounded, color: AppTheme.primary),
                onTap: () => Navigator.pop(context, w),
              )),
            ],
          ),
        );
        if (result != null) onSelect(result);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: selected != null
              ? AppTheme.primary.withValues(alpha: 0.08)
              : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
              color: selected != null ? AppTheme.primary : AppTheme.border),
        ),
        child: Row(children: [
          const Icon(Icons.warehouse_outlined, size: 16, color: AppTheme.primary),
          const SizedBox(width: 6),
          Expanded(child: Text(
            selected?.name ?? label,
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                color: selected != null ? AppTheme.primary : AppTheme.textHint),
            maxLines: 1, overflow: TextOverflow.ellipsis,
          )),
          const Icon(Icons.expand_more_rounded, size: 16, color: AppTheme.textHint),
        ]),
      ),
    );
  }
}

class _ProductPicker extends StatelessWidget {
  final FirestoreService service;
  final String warehouseId;
  final ProductModel? selected;
  final ValueChanged<ProductModel> onSelect;
  const _ProductPicker({required this.service, required this.warehouseId,
      required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ProductModel>>(
      stream: service.watchProducts(),
      builder: (_, snap) {
        final products = snap.data ?? [];
        return GestureDetector(
          onTap: () async {
            if (products.isEmpty) return;
            final result = await showModalBottomSheet<ProductModel>(
              context: context,
              shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
              builder: (_) => ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                children: [
                  const Text('Тауар таңдаңыз', style: TextStyle(fontSize: 16,
                      fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
                  const SizedBox(height: 12),
                  ...products.map((p) => ListTile(
                    title: Text(p.name),
                    subtitle: Text(p.brand),
                    onTap: () => Navigator.pop(context, p),
                  )),
                ],
              ),
            );
            if (result != null) onSelect(result);
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: selected != null ? AppTheme.primary : AppTheme.border),
            ),
            child: Row(children: [
              const Icon(Icons.inventory_2_outlined, color: AppTheme.primary, size: 18),
              const SizedBox(width: 10),
              Expanded(child: Text(
                selected != null ? '${selected!.name} — ${selected!.brand}' : 'Тауар таңдаңыз',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500,
                    color: selected != null ? AppTheme.textPrimary : AppTheme.textHint),
              )),
              const Icon(Icons.expand_more_rounded, size: 18, color: AppTheme.textHint),
            ]),
          ),
        );
      },
    );
  }
}

class _SizeSelector extends StatelessWidget {
  final FirestoreService service;
  final String productId, warehouseId;
  final Map<String, int> sizes;
  final ValueChanged<Map<String, int>> onChanged;
  const _SizeSelector({required this.service, required this.productId,
      required this.warehouseId, required this.sizes, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: service.getBatches(productId),
      builder: (_, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator(color: AppTheme.primary));
        }
        final batches = snap.data!.where((b) => b.warehouseId == warehouseId).toList();
        final available = <String, int>{};
        for (final b in batches) {
          for (final e in b.sizesQuantity.entries) {
            available[e.key] = (available[e.key] ?? 0) + e.value;
          }
        }
        final sizeKeys = available.keys.toList()..sort();
        return Wrap(
          spacing: 8, runSpacing: 8,
          children: sizeKeys.map((size) {
            final max = available[size] ?? 0;
            final cur = sizes[size] ?? 0;
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: cur > 0 ? AppTheme.primary.withValues(alpha: 0.08) : Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: cur > 0 ? AppTheme.primary : AppTheme.border),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Text(size, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600,
                    color: cur > 0 ? AppTheme.primary : AppTheme.textPrimary)),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: () {
                    if (cur > 0) {
                      final n = Map<String, int>.from(sizes);
                      n[size] = cur - 1;
                      onChanged(n);
                    }
                  },
                  child: const Icon(Icons.remove_circle_outline,
                      size: 16, color: AppTheme.danger)),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Text('$cur', style: const TextStyle(
                      fontSize: 12, fontWeight: FontWeight.w700, color: AppTheme.textPrimary)),
                ),
                GestureDetector(
                  onTap: () {
                    if (cur < max) {
                      final n = Map<String, int>.from(sizes);
                      n[size] = cur + 1;
                      onChanged(n);
                    }
                  },
                  child: const Icon(Icons.add_circle_outline,
                      size: 16, color: AppTheme.success)),
                const SizedBox(width: 4),
                Text('/$max', style: const TextStyle(
                    fontSize: 10, color: AppTheme.textHint)),
              ]),
            );
          }).toList(),
        );
      },
    );
  }
}
