import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/app_user.dart';
import '../../data/services/auth_service.dart';
import '../../theme/qoima_design.dart';

/// «Поштаны растау» экраны — кірген клиентке арналған. Клиент аккаунтқа кірген,
/// бірақ поштасы әлі расталмаған: бұл экраннан растау сілтемесін жібереді де,
/// сілтемені басқан соң «Растадым» батырмасымен күйді жаңартады. Расталғанда
/// [AppUser.emailVerified] true болады және экран `true` нәтижесімен жабылады.
class EmailVerificationScreen extends StatefulWidget {
  const EmailVerificationScreen({super.key});

  @override
  State<EmailVerificationScreen> createState() =>
      _EmailVerificationScreenState();
}

class _EmailVerificationScreenState extends State<EmailVerificationScreen> {
  final _authService = AuthService();
  bool _sending = false;
  bool _checking = false;
  int _cooldown = 0;
  Timer? _timer;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startCooldown() {
    _timer?.cancel();
    setState(() => _cooldown = 45);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      if (_cooldown <= 1) {
        t.cancel();
        setState(() => _cooldown = 0);
      } else {
        setState(() => _cooldown--);
      }
    });
  }

  Future<void> _send() async {
    setState(() => _sending = true);
    try {
      await _authService.sendVerificationToCurrentUser();
      if (!mounted) return;
      _startCooldown();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Растау сілтемесі жіберілді'),
        behavior: SnackBarBehavior.floating,
        backgroundColor: cGreen,
      ));
    } on AuthFailure catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(e.message),
          behavior: SnackBarBehavior.floating,
          backgroundColor: cRed,
        ));
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _check() async {
    setState(() => _checking = true);
    try {
      final verified = await _authService.reloadEmailVerified();
      if (!mounted) return;
      if (verified) {
        context.read<AppUser>().setEmailVerified(true);
        Navigator.pop(context, true);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Пошта расталды! ✓'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: cGreen,
        ));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Пошта әлі расталмаған. Сілтемені басып, қайталаңыз.'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: cRed,
        ));
      }
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final email = context.watch<AppUser>().email;
    return Scaffold(
      backgroundColor: cBg,
      body: Column(children: [
        QGradientHeader(
          title: 'Поштаны растау',
          showBack: true,
          onBack: () => Navigator.pop(context),
        ),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(22, 28, 22, 30),
            child: Column(children: [
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(
                  color: cGreenTint,
                  borderRadius: BorderRadius.circular(26),
                ),
                child: const Icon(Icons.mark_email_unread_outlined,
                    color: cGreen, size: 40),
              ),
              const SizedBox(height: 22),
              Text('Поштаңызды растаңыз',
                  style: manrope(20, FontWeight.w800, color: cInk),
                  textAlign: TextAlign.center),
              const SizedBox(height: 10),
              Text(
                email.isNotEmpty
                    ? 'Растау сілтемесі $email адресіне жіберіледі.'
                    : 'Растау сілтемесін поштаңызға жібереміз.',
                style: manrope(14.5, FontWeight.w500, color: cInk2, height: 1.5),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 6),
              Text(
                'Сілтемені басқан соң, осы экранға оралып «Растадым» батырмасын '
                'басыңыз. Пошта расталғанша тауар сатып ала алмайсыз.',
                style: manrope(13, FontWeight.w500, color: cInk3, height: 1.5),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),

              // Растадым — тексеру (негізгі)
              QPrimaryButton(
                label: 'Растадым',
                isLoading: _checking,
                onPressed: _check,
              ),
              const SizedBox(height: 12),

              // Растау сілтемесін жіберу / қайта жіберу
              SizedBox(
                width: double.infinity,
                height: 52,
                child: OutlinedButton(
                  onPressed: (_sending || _cooldown > 0) ? null : _send,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: cGreen,
                    side: const BorderSide(color: cGreen, width: 1.5),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15)),
                  ),
                  child: _sending
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              color: cGreen, strokeWidth: 2))
                      : Text(
                          _cooldown > 0
                              ? 'Қайта жіберу ($_cooldown)'
                              : 'Растау сілтемесін жіберу',
                          style: manrope(15, FontWeight.w700, color: cGreen)),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
