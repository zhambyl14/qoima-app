import 'dart:convert';
import 'dart:io' show Platform;
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart' show kIsWeb, debugPrint;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'local_notification_service.dart';

/// FCM хабарламасы осы арна арқылы келуі керек — AndroidManifest.xml-дегі
/// `com.google.firebase.messaging.default_notification_channel_id` мета-
/// деректерімен және send-push edge function-дағы android.notification.
/// channel_id-мен ДӘЛ бірдей болуы міндетті. Жоғары маңыздылық (HIGH) болмаса,
/// хабарлама тек статус-барға үнсіз түседі, экран үстіне баннер болып
/// қалқымайды (heads-up).
const String kPushChannelId = 'high_importance_channel';
const String kPushChannelName = 'Важные уведомления';

/// Firebase-тің фондық isolate-інде шақырылады (қолданба background/
/// terminated күйде FCM хабарламасы келгенде). ТОП-ДЕҢГЕЙ функция болуы
/// МІНДЕТТІ (класс әдісі жарамайды) — Flutter/Firebase талабы. «notification»
/// өрісі бар хабарламаларды осы режимде OS өзі автоматты көрсетеді, сол
/// себепті денесі бос — тек хендлер тіркелмеді деген Firebase ескертуін
/// болдырмау және болашақ data-only өңдеу үшін орын дайындау мақсатында.
@pragma('vm:entry-point')
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {}

/// FCM push-хабарламалар сервисі.
///
/// Backend Supabase күйінде қалады — Firebase ТЕК push жеткізу үшін
/// (fcm_tokens кестесі + send-push edge function → FCM v1 API).
/// Firebase конфигі жоқ/қате болса қолданба құламайды — push жай өшік тұрады.
class PushService {
  PushService._();
  static final PushService instance = PushService._();

  bool _firebaseReady = false;
  String? _lastSavedToken;

  SupabaseClient get _sb => Supabase.instance.client;

  /// Push баннерін басып ашқанда (background тап немесе cold start) шақырылады
  /// — data payload-пен. Қазір навигация роутері жоқ, сол себепті бұл — UI
  /// қабатына data-ны жеткізетін кеңею нүктесі (мыс. белгілі бір экранға
  /// секіру). Тіркелмесе — тек debugPrint-пен шектеледі.
  void Function(Map<String, dynamic> data)? onNotificationOpen;

  /// main()-де бір рет: Firebase-ті көтереміз. Сәтсіз болса (конфиг жоқ,
  /// желі т.б.) — үнсіз өтеміз, қолданба push-сыз жұмыс істей береді.
  ///
  /// МАҢЫЗДЫ: LocalNotificationService.instance.init() бұдан БҰРЫН
  /// аяқталған болуы керек (main.dart-та шақыру ретін қараңыз) — foreground
  /// FCM хабарламасын local notification ретінде көрсету үшін _plugin
  /// дайын тұруы қажет.
  Future<void> init() async {
    if (kIsWeb) return; // web push (VAPID) — бөлек баптау, әзірге қосылмаған
    try {
      await Firebase.initializeApp();
      _firebaseReady = true;
      // iOS: қолданба ашық тұрғанда да жүйелік баннер көрсетілсін (APNs
      // өзі баннер/дыбыс/badge шығарады — қосымша local notification
      // ЖАСАМАЙМЫЗ, әйтпесе екі рет көрінеді).
      await FirebaseMessaging.instance
          .setForegroundNotificationPresentationOptions(
              alert: true, badge: true, sound: true);
      // Android: HIGH маңыздылық арнасын алдын ала жасаймыз (FCM хабарламасы
      // осыған келгенде heads-up баннер ретінде қалқиды, тек шторкаға емес).
      if (!kIsWeb && Platform.isAndroid) {
        const channel = AndroidNotificationChannel(
          kPushChannelId,
          kPushChannelName,
          description: 'Заказы, продажи, возвраты и отзывы',
          importance: Importance.high,
        );
        await FlutterLocalNotificationsPlugin()
            .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>()
            ?.createNotificationChannel(channel);
      }
      // Токен жаңарса — тіркелген қолданушыға қайта сақтаймыз.
      FirebaseMessaging.instance.onTokenRefresh.listen((t) {
        final uid = _sb.auth.currentUser?.id;
        if (uid != null) _saveToken(t);
      });
      // Android: foreground-та local notification ретінде көрсетілген
      // push-ты пайдаланушы бассы — сол да background/cold-start тапталуымен
      // БІРДЕЙ _handleOpen жолымен жүреді (бір ғана onNotificationOpen хугі).
      LocalNotificationService.instance.onPushTap = _handleOpen;
      // Фондық isolate хендлер — background/terminated күйдегі хабарламаны
      // дұрыс өңдеу үшін тіркелуі МІНДЕТТІ (тіркелмесе Firebase ескертеді,
      // кейбір платформаларда getInitialMessage/аналитика тұрақсыз жұмыс
      // істейді).
      FirebaseMessaging.onBackgroundMessage(firebaseMessagingBackgroundHandler);

      // ── FOREGROUND: НЕГІЗГІ ТҮЗЕТУ ──────────────────────────────────────
      // FCM «notification» пейлоуын OS foreground-та АВТОМАТТЫ көрсетпейді
      // (Android-та тек background/terminated күйде көрсетеді — бос қалу
      // багының түбірлік себебі осы еді). Мұнда қолмен ұстап, local
      // notification ретінде көрсетеміз (Android). iOS-те жоғарыдағы
      // setForegroundNotificationPresentationOptions арқылы APNs өзі
      // баннер шығарады, сол себепті қайталап көрсетпейміз.
      FirebaseMessaging.onMessage.listen(_handleForegroundMessage);

      // Қолданба фонда тұрып, пайдаланушы push баннерін басып ашса.
      FirebaseMessaging.onMessageOpenedApp.listen((m) => _handleOpen(m.data));

      // Қолданба МҮЛДЕМ жабық күйде push басып ашылса (cold start) —
      // алғашқы кадрдан кейін тексереміз.
      final initial = await FirebaseMessaging.instance.getInitialMessage();
      if (initial != null) _handleOpen(initial.data);
    } catch (e) {
      debugPrint('PushService init skipped: $e');
    }
  }

  /// Foreground-та келген FCM хабарламасын Android-та local notification
  /// ретінде көрсетеді (iOS-ті APNs өзі жүйелік деңгейде көрсетеді —
  /// setForegroundNotificationPresentationOptions арқылы).
  Future<void> _handleForegroundMessage(RemoteMessage message) async {
    final n = message.notification;
    if (n == null) return; // тек data-хабарлама — көрсетілетін мәтін жоқ
    if (kIsWeb || !Platform.isAndroid) return;
    await LocalNotificationService.instance.showPush(
      channelId: kPushChannelId,
      channelName: kPushChannelName,
      title: n.title ?? '',
      body: n.body ?? '',
      payload: jsonEncode(message.data),
    );
  }

  void _handleOpen(Map<String, dynamic> data) {
    debugPrint('PushService: notification opened, data=$data');
    onNotificationOpen?.call(data);
  }

  /// Логиннен кейін: рұқсат сұрап, токенді fcm_tokens-ке жазамыз.
  /// [role] — хабарламаларды рөл бойынша бағыттау үшін (admin/seller/client).
  Future<void> registerForUser({required String role}) async {
    if (!_firebaseReady) return;
    try {
      final settings = await FirebaseMessaging.instance.requestPermission(
          alert: true, badge: true, sound: true);
      if (settings.authorizationStatus == AuthorizationStatus.denied) return;

      // iOS: FCM токенін алудан БҰРЫН Apple-дың APNs токені дайын болуы керек.
      // Құрылғы логынан расталды: apsd байланысы (APSConnection) кейде
      // ~1.5 минутқа дейін созылады (10 секунд ЖЕТКІЛІКСІЗ болды — токен
      // сол себепті сақталмай қалды). Сол себепті ұзағырақ (макс ~2 мин)
      // қайталап күтеміз. await жоқ шақыруда тұрғандықтан (логинді
      // бөгемейді) — бұл ешбір UI-ды тоспайды.
      if (!kIsWeb && Platform.isIOS) {
        String? apns = await FirebaseMessaging.instance.getAPNSToken();
        for (var i = 0; apns == null && i < 40; i++) {
          await Future.delayed(const Duration(seconds: 3));
          apns = await FirebaseMessaging.instance.getAPNSToken();
        }
        // Әлі де жоқ болса — токенді кейін onTokenRefresh/келесі кіру тіркейді.
        if (apns == null) {
          debugPrint('PushService: APNs token not ready yet, will retry later');
          return;
        }
      }

      final token = await FirebaseMessaging.instance.getToken();
      if (token == null || token.isEmpty) return;
      await _saveToken(token, role: role);
    } catch (e) {
      debugPrint('PushService register skipped: $e');
    }
  }

  Future<void> _saveToken(String token, {String role = ''}) async {
    final uid = _sb.auth.currentUser?.id;
    if (uid == null) return;
    if (_lastSavedToken == token && role.isEmpty) return;
    try {
      await _sb.from('fcm_tokens').upsert({
        'token': token,
        'uid': uid,
        if (role.isNotEmpty) 'role': role,
        'platform': kIsWeb
            ? 'web'
            : Platform.isIOS
                ? 'ios'
                : 'android',
        'updated_at': DateTime.now().toIso8601String(),
      }, onConflict: 'token');
      _lastSavedToken = token;
    } catch (e) {
      debugPrint('PushService save token failed: $e');
    }
  }

  /// Шығу алдында: осы құрылғының токенін өшіреміз — басқа аккаунтқа
  /// арналған push бұл құрылғыға келмейді.
  Future<void> unregister() async {
    if (!_firebaseReady) return;
    try {
      final token = await FirebaseMessaging.instance.getToken();
      if (token != null && token.isNotEmpty) {
        await _sb.from('fcm_tokens').delete().eq('token', token);
      }
      _lastSavedToken = null;
    } catch (_) {}
  }
}
